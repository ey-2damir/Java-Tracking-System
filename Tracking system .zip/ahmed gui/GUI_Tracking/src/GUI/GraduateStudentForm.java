package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

public class GraduateStudentForm {
    static Connection con;
    static PreparedStatement pst;
    static JTable table;

    public static void main(String[] args) {
        // الاتصال بقاعدة البيانات
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/tracking_system", "root", "");
            JOptionPane.showMessageDialog(null, "تم الاتصال بنجاح");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // إعداد نافذة Graduate Student Form
        JFrame CRUD = new JFrame("Graduate Student Form");
        CRUD.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DUBAI_KEY\\Desktop\\1674050617804.jpeg"));
        CRUD.getContentPane().setFont(new Font("Dialog", Font.BOLD, 12));
        CRUD.getContentPane().setBackground(new Color(132, 207, 236));
        CRUD.setResizable(true);
        CRUD.setBounds(500, 30, 700, 800);
        CRUD.getContentPane().setLayout(null);

        // عناصر الإدخال
        JLabel nameLabel = new JLabel("Student Name");
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        nameLabel.setBounds(27, 180, 120, 30);
        CRUD.getContentPane().add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(134, 181, 200, 30);
        CRUD.getContentPane().add(nameField);

        JLabel phoneLabel = new JLabel("Phone");
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        phoneLabel.setBounds(37, 221, 133, 30);
        CRUD.getContentPane().add(phoneLabel);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(134, 222, 200, 30);
        CRUD.getContentPane().add(phoneField);

        JLabel addressLabel = new JLabel("Address");
        addressLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        addressLabel.setBounds(354, 180, 120, 30);
        CRUD.getContentPane().add(addressLabel);

        JTextField addressField = new JTextField();
        addressField.setBounds(432, 181, 200, 30);
        CRUD.getContentPane().add(addressField);

        JLabel departmentLabel = new JLabel("Department");
        departmentLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        departmentLabel.setBounds(344, 221, 120, 30);
        CRUD.getContentPane().add(departmentLabel);

        JTextField departmentField = new JTextField();
        departmentField.setBounds(432, 222, 200, 30);
        CRUD.getContentPane().add(departmentField);

        JLabel availabilityStatusLabel = new JLabel("Availability Status");
        availabilityStatusLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
        availabilityStatusLabel.setBounds(344, 261, 90, 30);
        CRUD.getContentPane().add(availabilityStatusLabel);

        JTextField availabilityStatusField = new JTextField();
        availabilityStatusField.setBounds(432, 263, 200, 30);
        CRUD.getContentPane().add(availabilityStatusField);

        JLabel lastCommunicationDateLabel = new JLabel("Last Communication Date:");
        lastCommunicationDateLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
        lastCommunicationDateLabel.setBounds(10, 262, 125, 30);
        CRUD.getContentPane().add(lastCommunicationDateLabel);

        JTextField lastCommunicationDateField = new JTextField();
        lastCommunicationDateField.setBounds(134, 264, 200, 30);
        CRUD.getContentPane().add(lastCommunicationDateField);

        JLabel lookupLabel = new JLabel("Search by ID:");
        lookupLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        lookupLabel.setBounds(162, 91, 100, 30);
        CRUD.getContentPane().add(lookupLabel);

        JTextField lookupField = new JTextField();
        lookupField.setBounds(264, 94, 200, 30);
        CRUD.getContentPane().add(lookupField);

        // زر البحث
        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Dialog", Font.BOLD, 12));
        searchButton.setBounds(484, 93, 100, 30);
        CRUD.getContentPane().add(searchButton);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = lookupField.getText();
                try {
                    pst = con.prepareStatement("SELECT Name, Phone, Address, Department, AvailabilityStatus, LastCommunicationDate FROM graduatestudent WHERE StudentID = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();
                    if (rs.next()) {
                        nameField.setText(rs.getString("Name"));
                        phoneField.setText(rs.getString("Phone"));
                        addressField.setText(rs.getString("Address"));
                        departmentField.setText(rs.getString("Department"));
                        availabilityStatusField.setText(rs.getString("AvailabilityStatus"));
                        lastCommunicationDateField.setText(rs.getString("LastCommunicationDate"));
                    } else {
                        nameField.setText("");
                        phoneField.setText("");
                        addressField.setText("");
                        departmentField.setText("");
                        availabilityStatusField.setText("");
                        lastCommunicationDateField.setText("");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // زر إضافة Graduate Student
        JButton addButton = new JButton("Add Graduate");
        addButton.setFont(new Font("Dialog", Font.BOLD, 12));
        addButton.setBackground(new Color(0, 255, 64));
        addButton.setBounds(101, 374, 142, 30);
        CRUD.getContentPane().add(addButton);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String phone = phoneField.getText();
                String address = addressField.getText();
                String department = departmentField.getText();
                String availabilityStatus = availabilityStatusField.getText();
                String lastCommunicationDate = lastCommunicationDateField.getText();
                try {
                    pst = con.prepareStatement("INSERT INTO graduatestudent (Name, Phone, Address, Department, AvailabilityStatus, LastCommunicationDate) VALUES (?, ?, ?, ?, ?, ?)");
                    pst.setString(1, name);
                    pst.setString(2, phone);
                    pst.setString(3, address);
                    pst.setString(4, department);
                    pst.setString(5, availabilityStatus);
                    pst.setString(6, lastCommunicationDate);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Graduate Student Added Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    addressField.setText("");
                    departmentField.setText("");
                    availabilityStatusField.setText("");
                    lastCommunicationDateField.setText("");
                    loadTableData();  // تحديث الجدول بعد الإضافة
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر تحديث Graduate Student
        JButton updateButton = new JButton("Update Graduate");
        updateButton.setFont(new Font("Dialog", Font.BOLD, 12));
        updateButton.setBackground(new Color(0, 128, 192));
        updateButton.setBounds(275, 374, 139, 30);
        CRUD.getContentPane().add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(lookupField.getText());
                String name = nameField.getText();
                String phone = phoneField.getText();
                String address = addressField.getText();
                String department = departmentField.getText();
                String availabilityStatus = availabilityStatusField.getText();
                String lastCommunicationDate = lastCommunicationDateField.getText();
                try {
                    pst = con.prepareStatement("UPDATE graduatestudent SET Name = ?, Phone = ?, Address = ?, Department = ?, AvailabilityStatus = ?, LastCommunicationDate = ? WHERE StudentID = ?");
                    pst.setString(1, name);
                    pst.setString(2, phone);
                    pst.setString(3, address);
                    pst.setString(4, department);
                    pst.setString(5, availabilityStatus);
                    pst.setString(6, lastCommunicationDate);
                    pst.setInt(7, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Graduate Student Updated Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    addressField.setText("");
                    departmentField.setText("");
                    availabilityStatusField.setText("");
                    lastCommunicationDateField.setText("");
                    loadTableData();  // تحديث الجدول بعد التعديل
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر حذف Graduate Student
        JButton deleteButton = new JButton("Delete Graduate");
        deleteButton.setFont(new Font("Dialog", Font.BOLD, 12));
        deleteButton.setBackground(new Color(255, 0, 0));
        deleteButton.setBounds(445, 374, 139, 30);
        CRUD.getContentPane().add(deleteButton);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(lookupField.getText());
                try {
                    pst = con.prepareStatement("DELETE FROM graduatestudent WHERE StudentID = ?");
                    pst.setInt(1, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Graduate Student Deleted Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    addressField.setText("");
                    departmentField.setText("");
                    availabilityStatusField.setText("");
                    lastCommunicationDateField.setText("");
                    lookupField.setText("");
                    loadTableData();  // تحديث الجدول بعد الحذف
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر العودة إلى نافذة TrackerForm
        JButton backButton = new JButton("Go to Trackers");
        backButton.setFont(new Font("Dialog", Font.BOLD, 11));
        backButton.setBounds(10, 10, 120, 30);
        CRUD.getContentPane().add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TrackerForm.main(null); // بدلاً من إنشاء كائن جديد
                CRUD.setVisible(false); // إخفاء النافذة الحالية
            }
        });

        // جدول لعرض بيانات الخريجين
        String[] columns = {"StudentID", "Name", "Phone", "Address", "Department", "AvailabilityStatus", "LastCommunicationDate"};
        table = new JTable(new DefaultTableModel(columns, 0));  // استخدام متغير table الذي تم تعريفه
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(27, 429, 636, 250);
        CRUD.getContentPane().add(scrollPane);

        // تحميل البيانات في الجدول عند فتح النافذة
        loadTableData();

        CRUD.setVisible(true);
    }

    // دالة لتحميل البيانات في الجدول
    private static void loadTableData() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);  // مسح الجدول من البيانات السابقة

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM graduatestudent");
            while (rs.next()) {
                Object[] row = new Object[7];
                row[0] = rs.getInt("StudentID");
                row[1] = rs.getString("Name");
                row[2] = rs.getString("Phone");
                row[3] = rs.getString("Address");
                row[4] = rs.getString("Department");
                row[5] = rs.getString("AvailabilityStatus");
                row[6] = rs.getString("LastCommunicationDate");
                model.addRow(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
