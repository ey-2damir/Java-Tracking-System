package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;
import java.awt.Toolkit;
import java.awt.Font;
import java.awt.Color;

public class TrackerForm {
    static Connection con;
    static PreparedStatement pst;
    static JTable table; // تعريف متغير table على مستوى الفصل

    public static void main(String[] args) {
        // الاتصال بقاعدة البيانات
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/tracking_system", "root", "");
           // JOptionPane.showMessageDialog(null, "Connection Success");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // إعداد نافذة Tracker Form
        JFrame CRUD = new JFrame("Tracker Form");
        CRUD.getContentPane().setBackground(new Color(132, 207, 236));
        CRUD.getContentPane().setForeground(new Color(132, 207, 236));
        CRUD.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DUBAI_KEY\\Desktop\\1674050617804.jpeg"));
        CRUD.setResizable(true);
        CRUD.setBounds(500, 50, 600, 800);
        CRUD.getContentPane().setLayout(null);

        // عناصر الإدخال
        JLabel nameLabel = new JLabel("Tracker Name:");
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        nameLabel.setBounds(78, 136, 308, 30);
        CRUD.getContentPane().add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(196, 139, 202, 30);
        CRUD.getContentPane().add(nameField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        phoneLabel.setBounds(90, 213, 308, 30);
        CRUD.getContentPane().add(phoneLabel);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(196, 214, 202, 30);
        CRUD.getContentPane().add(phoneField);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        roleLabel.setBounds(90, 178, 308, 30);
        CRUD.getContentPane().add(roleLabel);

        JTextField roleField = new JTextField();
        roleField.setBounds(196, 178, 202, 30);
        CRUD.getContentPane().add(roleField);

        JLabel lookupLabel = new JLabel("Search by ID:");
        lookupLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
        lookupLabel.setBounds(90, 78, 100, 30);
        CRUD.getContentPane().add(lookupLabel);

        JTextField lookupField = new JTextField();
        lookupField.setBounds(196, 80, 202, 30);
        CRUD.getContentPane().add(lookupField);

        // زر البحث
        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        searchButton.setBounds(406, 78, 100, 30);
        CRUD.getContentPane().add(searchButton);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = lookupField.getText();
                try {
                    pst = con.prepareStatement("SELECT Name, Phone, Role FROM Tracker WHERE TrackerID = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();
                    if (rs.next()) {
                        nameField.setText(rs.getString("Name"));
                        phoneField.setText(rs.getString("Phone"));
                        roleField.setText(rs.getString("Role"));
                    } else {
                        nameField.setText("");
                        phoneField.setText("");
                        roleField.setText("");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // زر إضافة Tracker
        JButton addButton = new JButton("Add Tracker");
        addButton.setForeground(new Color(5, 121, 226));
        addButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        addButton.setBounds(66, 297, 120, 30);
        CRUD.getContentPane().add(addButton);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String phone = phoneField.getText();
                String role = roleField.getText();
                try {
                    pst = con.prepareStatement("INSERT INTO Tracker (Name, Phone, Role) VALUES (?, ?, ?)");
                    pst.setString(1, name);
                    pst.setString(2, phone);
                    pst.setString(3, role);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Tracker Added Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    roleField.setText("");
                    loadTableData();  // تحديث الجدول بعد الإضافة
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر تحديث Tracker
        JButton updateButton = new JButton("Update Tracker");
        updateButton.setForeground(new Color(11, 255, 11));
        updateButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        updateButton.setBounds(231, 297, 120, 30);
        CRUD.getContentPane().add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(lookupField.getText());
                String name = nameField.getText();
                String phone = phoneField.getText();
                String role = roleField.getText();
                try {
                    pst = con.prepareStatement("UPDATE Tracker SET Name = ?, Phone = ?, Role = ? WHERE TrackerID = ?");
                    pst.setString(1, name);
                    pst.setString(2, phone);
                    pst.setString(3, role);
                    pst.setInt(4, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Tracker Updated Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    roleField.setText("");
                    loadTableData();  // تحديث الجدول بعد التعديل
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر حذف Tracker
        JButton deleteButton = new JButton("Delete Tracker");
        deleteButton.setForeground(new Color(255, 0, 0));
        deleteButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        deleteButton.setBounds(386, 297, 120, 30);
        CRUD.getContentPane().add(deleteButton);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(lookupField.getText());
                try {
                    pst = con.prepareStatement("DELETE FROM Tracker WHERE TrackerID = ?");
                    pst.setInt(1, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Tracker Deleted Successfully");
                    nameField.setText("");
                    phoneField.setText("");
                    roleField.setText("");
                    lookupField.setText("");
                    loadTableData();  // تحديث الجدول بعد الحذف
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        // زر الانتقال إلى نافذة GraduateStudentForm
        JButton backButton = new JButton("Go to Students");
        backButton.setBounds(10, 24, 120, 30);
        CRUD.getContentPane().add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GraduateStudentForm.main(null); // بدلاً من إنشاء كائن جديد
                CRUD.setVisible(false); // إخفاء النافذة الحالية
            }
        });


        // جدول لعرض بيانات Trackers
        String[] columns = {"TrackerID", "Name", "Phone", "Role"};
        table = new JTable(new DefaultTableModel(columns, 0));  // استخدام متغير table الذي تم تعريفه
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(46, 360, 480, 238);
        CRUD.getContentPane().add(scrollPane);

        // تحميل البيانات في الجدول عند فتح النافذة
        loadTableData();

        CRUD.setVisible(true);
    }

    // دالة لتحميل البيانات في الجدول
    private static void loadTableData() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // مسح البيانات القديمة
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Tracker");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("TrackerID"),
                        rs.getString("Name"),
                        rs.getString("Phone"),
                        rs.getString("Role")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
