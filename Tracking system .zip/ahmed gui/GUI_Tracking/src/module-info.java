/**
 * 
 */
/**
 * 
 */
module CRUD_project {
	requires java.desktop;
	requires java.sql;
}